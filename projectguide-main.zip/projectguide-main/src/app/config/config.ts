
 const config = {

    api: 'https://operation.dth.travel:7082'
    // api: 'https://localhost:5001'
}

export default config;